/* generated configuration header file - do not edit */
#ifndef R_MMU_CFG_H_
#define R_MMU_CFG_H_
#define MMU_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_MMU_CFG_H_ */
