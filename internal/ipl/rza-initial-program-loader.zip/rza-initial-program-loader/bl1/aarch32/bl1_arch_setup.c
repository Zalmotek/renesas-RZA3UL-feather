/*
 * Copyright (c) 2016, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "../bl1_private.h"

/*******************************************************************************
 * TODO: Function that does the first bit of architectural setup.
 ******************************************************************************/
void bl1_arch_setup(void)
{

}
